from django.urls import path
from .views import mentor_chat

urlpatterns = [
    path('chat/', mentor_chat, name='mentor_chat'),
]
