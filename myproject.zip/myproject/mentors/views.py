from rest_framework import generics
from .models import Mentor, ChatMessage
from .serializers import MentorSerializer, ChatMessageSerializer

class MentorListView(generics.ListCreateAPIView):
    queryset = Mentor.objects.all()
    serializer_class = MentorSerializer

class ChatMessageListView(generics.ListCreateAPIView):
    queryset = ChatMessage.objects.all()
    serializer_class = ChatMessageSerializer

class ChatMessageDetailView(generics.RetrieveAPIView):
    queryset = ChatMessage.objects.all()
    serializer_class = ChatMessageSerializer

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Mentor, ChatMessage
from .forms import ChatMessageForm

@login_required
def mentor_chat(request):
    mentor = Mentor.objects.first()
    messages = ChatMessage.objects.filter(sender=request.user) | ChatMessage.objects.filter(receiver=request.user)
    messages = messages.order_by('sent_at')
    if request.method == 'POST':
        form = ChatMessageForm(request.POST)
        if form.is_valid():
            chat_message = form.save(commit=False)
            chat_message.sender = request.user
            chat_message.receiver = mentor.user
            chat_message.save()
            return redirect('mentor_chat')
    else:
        form = ChatMessageForm()
    return render(request, 'chat.html', {'form': form, 'messages': messages, 'mentor': mentor})
