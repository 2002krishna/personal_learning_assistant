from django.db import models

class Resource(models.Model):
    title = models.CharField(max_length=255)
    type = models.CharField(max_length=50)
    url = models.URLField()
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
