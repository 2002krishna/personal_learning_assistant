from django.urls import path
from .views import resources_list

urlpatterns = [
    path('', resources_list, name='resources_list'),
]
