from rest_framework import generics
from .models import Resource
from .serializers import ResourceSerializer

class ResourceListView(generics.ListCreateAPIView):
    queryset = Resource.objects.all()
    serializer_class = ResourceSerializer

class ResourceDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Resource.objects.all()
    serializer_class = ResourceSerializer

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Resource

@login_required
def resources_list(request):
    resources = Resource.objects.all()
    return render(request, 'resources/resources.html', {'resources': resources})
