import pandas as pd
import numpy as np
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.layers import Input, LSTM, Embedding, Dense
from tensorflow.keras.models import Model
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from surprise import Dataset, Reader, SVD
import pickle
import joblib

# Sample data
data = [
    ("Python programming", "What is Python programming?"),
    ("Machine learning", "What is machine learning?"),
    ("Artificial Intelligence", "What is artificial intelligence?")
]

topics = [pair[0] for pair in data]
questions = [pair[1] for pair in data]

# Tokenize and pad sequences
tokenizer = Tokenizer()
tokenizer.fit_on_texts(topics + questions)
vocab_size = len(tokenizer.word_index) + 1
max_length = 10

def preprocess_text(text):
    sequence = tokenizer.texts_to_sequences([text])[0]
    return pad_sequences([sequence], maxlen=max_length, padding='post')[0]

topics_seq = np.array([preprocess_text(topic) for topic in topics])
questions_seq = np.array([preprocess_text(question) for question in questions])

embedding_dim = 100
latent_dim = 256

# Encoder
encoder_inputs = Input(shape=(max_length,))
encoder_embedding = Embedding(vocab_size, embedding_dim)(encoder_inputs)
encoder_lstm = LSTM(latent_dim, return_state=True)
encoder_outputs, state_h, state_c = encoder_lstm(encoder_embedding)
encoder_states = [state_h, state_c]

# Decoder
decoder_inputs = Input(shape=(max_length,))
decoder_embedding = Embedding(vocab_size, embedding_dim)(decoder_inputs)
decoder_lstm = LSTM(latent_dim, return_sequences=True, return_state=True)
decoder_outputs, _, _ = decoder_lstm(decoder_embedding, initial_state=encoder_states)
decoder_dense = Dense(vocab_size, activation='softmax')
decoder_outputs = decoder_dense(decoder_outputs)

# Define the model
model = Model([encoder_inputs, decoder_inputs], decoder_outputs)
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy')

# Prepare target data for training
decoder_target_data = np.zeros_like(questions_seq)
decoder_target_data[:, :-1] = questions_seq[:, 1:]

questions_seq = questions_seq.reshape((questions_seq.shape[0], questions_seq.shape[1], 1))

# Train the model
model.fit(
    [topics_seq, questions_seq],
    decoder_target_data,
    batch_size=32,
    epochs=100,
    validation_split=0.2
)

# Save the question generation model
model.save('question_generation_model.h5')

# Save the tokenizer
with open('tokenizer.pkl', 'wb') as handle:
    pickle.dump(tokenizer, handle, protocol=pickle.HIGHEST_PROTOCOL)

# Train and save the predictive model
def preprocess_data():
    data = pd.read_csv('ml/student_data.csv')
    X = data[['feature1', 'feature2', 'feature3']]
    y = data['target']
    return train_test_split(X, y, test_size=0.2, random_state=42)

X_train, X_test, y_train, y_test = preprocess_data()
gbr_model = GradientBoostingRegressor()
gbr_model.fit(X_train, y_train)

# Save the predictive model
joblib.dump(gbr_model, 'predictive_model.pkl')

# Train and save the recommendation model
reader = Reader(rating_scale=(1, 5))
ratings_data = Dataset.load_from_df(pd.read_csv('ml/ratings.csv')[['user_id', 'item_id', 'rating']], reader)
trainset = ratings_data.build_full_trainset()
svd_model = SVD()
svd_model.fit(trainset)

# Save the recommendation model
joblib.dump(svd_model, 'recommendation_model.pkl')
