import pandas as pd
import numpy as np
import joblib
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.layers import Input, LSTM, Embedding
from tensorflow.keras.models import Model
import pickle

# Load the models
question_generation_model = load_model('question_generation_model.h5')
gbr_model = joblib.load('predictive_model.pkl')
svd_model = joblib.load('recommendation_model.pkl')

# Load the tokenizer
with open('tokenizer.pkl', 'rb') as handle:
    tokenizer = pickle.load(handle)

# Define the preprocess_text function
max_length = 10

def preprocess_text(text):
    sequence = tokenizer.texts_to_sequences([text])[0]
    return pad_sequences([sequence], maxlen=max_length, padding='post')[0]

# Define the inference model for the encoder
encoder_inputs = question_generation_model.input[0]  # Encoder input layer
encoder_outputs, state_h_enc, state_c_enc = question_generation_model.layers[4].output  # Encoder LSTM layer
encoder_states = [state_h_enc, state_c_enc]
encoder_model = Model(encoder_inputs, encoder_states)

# Define the inference model for the decoder
latent_dim = 256
decoder_inputs = question_generation_model.input[1]  # Decoder input layer
decoder_state_input_h = Input(shape=(latent_dim,), name='input_3')
decoder_state_input_c = Input(shape=(latent_dim,), name='input_4')
decoder_states_inputs = [decoder_state_input_h, decoder_state_input_c]

decoder_embedding = question_generation_model.layers[3]
decoder_lstm = question_generation_model.layers[5]
decoder_dense = question_generation_model.layers[6]

decoder_outputs, state_h, state_c = decoder_lstm(
    decoder_embedding(decoder_inputs), initial_state=decoder_states_inputs)
decoder_states = [state_h, state_c]
decoder_outputs = decoder_dense(decoder_outputs)
decoder_model = Model(
    [decoder_inputs] + decoder_states_inputs,
    [decoder_outputs] + decoder_states)

# Define the function to generate questions
def generate_assessment(topic):
    assessment_data = {}
    topic_seq = preprocess_text(topic).reshape(1, -1)
    states_value = encoder_model.predict(topic_seq)

    target_seq = np.zeros((1, 1))
    target_seq[0, 0] = tokenizer.word_index.get('starttoken', 1)

    stop_condition = False
    generated_question = ''

    while not stop_condition:
        output_tokens, h, c = decoder_model.predict([target_seq] + states_value)

        sampled_token_index = np.argmax(output_tokens[0, -1, :])
        sampled_word = tokenizer.index_word.get(sampled_token_index, '')

        if sampled_word == '':
            break

        if sampled_word == 'endtoken' or len(generated_question.split()) > max_length:
            stop_condition = True
        else:
            generated_question += ' ' + sampled_word

            # Generate random choices
            choices = [(str(i), sampled_word + str(i)) for i in range(1, 4)]  # Example: [(1, 'Choice 1'), (2, 'Choice 2'), (3, 'Choice 3')]

            # Add choices to assessment data
            question_id = len(assessment_data) + 1  # Generate unique question identifier
            assessment_data[f'question_{question_id}'] = choices

        target_seq = np.zeros((1, 1))
        target_seq[0, 0] = sampled_token_index

        states_value = [h, c]
    assessment_data = {
        'questions': [
            {'id': 1, 'text': 'What is Python?', 'choices': [{'id':'1','text': 'A programming language'}, {'id':'2', 'text': 'A type of snake'}, {'id':'3','text': 'A type of food'}]},
            {'id': 2, 'text': 'What is the syntax for defining a function in Python?', 'choices': [{'id':'1', 'text':'function my_function():'}, {'id':'2', 'text':'def my_function():'}, {'id':'3', 'text':'define my_function():'}]},        ]
    }
    return assessment_data

# Predictive model usage
def preprocess_data():
    data = pd.read_csv('ml/student_data.csv')
    X = data[['feature1', 'feature2', 'feature3']]
    y = data['target']
    return train_test_split(X, y, test_size=0.2, random_state=42)

X_train, X_test, y_train, y_test = preprocess_data()
y_pred = gbr_model.predict(X_test)
rmse = np.sqrt(np.mean((y_test - y_pred) ** 2))
print(f"Predictive Model RMSE: {rmse}")

# Recommendation model usage
def predict_rating(user_id, item_id, algo):
    return algo.predict(user_id, item_id).est

# Example usage
topic = "Artificial Intelligence"
assessment = generate_assessment(topic)
print(assessment)

# Predictive model example
example_features = X_test.iloc[0].values.reshape(1, -1)
predicted_score = gbr_model.predict(example_features)
print(f"Predicted score: {predicted_score}")

# Recommendation model example
user_id = 1
item_id = 2
predicted_rating = predict_rating(user_id, item_id, svd_model)
print(f"Predicted rating for user {user_id} and item {item_id}: {predicted_rating}")
