from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import StudyPlan, StudyPlanStep
import networkx as nx
import matplotlib.pyplot as plt
from io import BytesIO
import base64

def generate_study_plan(assessment_result):

    study_plan = StudyPlan.objects.create(
        user=assessment_result.user,
        topic=assessment_result.assessment.title,
        duration=7
    )

    steps = [
        {"step_number": 1, "description": "Introduction to the basics", "resources": [{"title": "Intro Video", "url": "https://example.com/intro"}], "duration": 1},
        {"step_number": 2, "description": "Deep dive into topic", "resources": [{"title": "Deep Dive Video", "url": "https://example.com/deepdive"}], "duration": 2},
    ]

    for step in steps:
        StudyPlanStep.objects.create(
            study_plan=study_plan,
            step_number=step["step_number"],
            description=step["description"],
            resources=step["resources"],
            duration=step["duration"]
        )

    # Generate the roadmap graph
    graph_data = generate_roadmap_graph(study_plan)

    return study_plan, graph_data

def generate_roadmap_graph(study_plan):
    # Create a directed graph
    G = nx.DiGraph()

    # Add nodes and edges to the graph based on study plan steps
    for step in study_plan.steps.all():
        G.add_node(step.step_number, label=step.description)

    # Add edges between nodes based on the sequence of steps in the study plan
    steps = list(study_plan.steps.all())
    for i in range(len(steps) - 1):
        G.add_edge(steps[i].step_number, steps[i+1].step_number)

    # Generate the graph visualization
    plt.figure(figsize=(8, 4))

    # Draw nodes with labels in square shape
    pos = nx.spring_layout(G)
    labels = nx.get_node_attributes(G, 'label')
    nx.draw_networkx_nodes(G, pos, node_size=8000, node_color='lightblue', label=labels.keys(), node_shape='s')
    nx.draw_networkx_labels(G, pos, labels=labels, font_weight='bold', font_size=7)

    # Draw edges with reduced arrow size
    nx.draw_networkx_edges(G, pos, arrowsize=1)

    # Hide axes
    plt.axis('off')

    # Convert the plot to a bytes object
    buf = BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    graph_data = base64.b64encode(buf.read()).decode('utf-8')
    plt.close()

    return graph_data


@login_required
def study_plan(request):
    study_plan_id =1 
    # study_plan = get_object_or_404(StudyPlan, user=request.user)
    # graph_data = generate_roadmap_graph(study_plan)
    return render(request, 'studyplans/study_plan.html')
