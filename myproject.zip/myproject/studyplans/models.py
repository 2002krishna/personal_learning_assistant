from django.db import models
from users.models import CustomUser

class StudyPlan(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    topic = models.CharField(max_length=255)
    duration = models.IntegerField()  # Duration in days
    created_at = models.DateTimeField(auto_now_add=True)

class StudyPlanStep(models.Model):
    study_plan = models.ForeignKey(StudyPlan, on_delete=models.CASCADE, related_name='steps')
    step_number = models.IntegerField()
    description = models.TextField()
    resources = models.JSONField()  # JSON field to store a list of resources
    duration = models.IntegerField()  # Duration in days for this step
    completed = models.BooleanField(default=False)
