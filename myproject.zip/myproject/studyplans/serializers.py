from rest_framework import serializers
from .models import StudyPlan, StudyPlanStep

class StudyPlanSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudyPlan
        fields = '__all__'

class StudyPlanStepSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudyPlanStep
        fields = '__all__'
