from django.urls import path
from .views import study_plan

urlpatterns = [
    path('study_plan/1/', study_plan, name='study_plan'),
]
