from django.apps import AppConfig


class StudyplansConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'studyplans'
