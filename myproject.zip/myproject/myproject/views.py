from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from studyplans.models import StudyPlan
from assessments.models import AssessmentResult

def home(request):
    return render(request, 'home.html')

@login_required
def dashboard(request):
    study_plans = StudyPlan.objects.filter(user=request.user)
    assessment_results = AssessmentResult.objects.filter(user=request.user)
    return render(request, 'dashboard.html', {
        'study_plans': study_plans,
        'assessment_results': assessment_results
    })


from django.shortcuts import redirect

def redirect_to_profile(request):
    return redirect('profile')

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required

@login_required
def select_topic(request):
    if request.method == 'POST':
        topic = request.POST.get('topic')
        return redirect('initial_assessment', topic=topic)
    return render(request, 'select_topic.html')


