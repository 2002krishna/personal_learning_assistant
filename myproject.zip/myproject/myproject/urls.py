from django.contrib import admin
from django.urls import path, include
from .views import home, dashboard, redirect_to_profile,select_topic

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),
    path('dashboard/', dashboard, name='dashboard'),
    path('users/', include('users.urls')),
    path('assessments/', include('assessments.urls')),
    path('studyplans/', include('studyplans.urls')),
    path('resources/', include('resources.urls')),
    path('mentors/', include('mentors.urls')),
    path('accounts/', include('django.contrib.auth.urls')),
    path('accounts/profile/', redirect_to_profile),
    path('select_topic/', select_topic, name='select_topic'),
]