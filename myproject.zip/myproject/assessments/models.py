# models.py
from django.db import models
from users.models import CustomUser

class Assessment(models.Model):
    title = models.CharField(max_length=255)
    questions = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)

class AssessmentResult(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    assessment = models.ForeignKey(Assessment, on_delete=models.CASCADE,default=dict)
    score = models.FloatField(default=0.0)
    answers = models.JSONField(null=True, blank=True)
    taken_at = models.DateTimeField(auto_now_add=True)
    assessment_json = models.JSONField(null=True, blank=True)  # New field
