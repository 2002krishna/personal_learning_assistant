from django.urls import path
from .views import initial_assessment

urlpatterns = [
    path('initial_assessment/<str:topic>/', initial_assessment, name='initial_assessment'),
]
