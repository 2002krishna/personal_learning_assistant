from django import forms
from .models import AssessmentResult

class AssessmentForm(forms.ModelForm):
    class Meta:
        model = AssessmentResult
        fields = ['answers']

    def __init__(self, *args, **kwargs):
        assessment = kwargs.pop('assessment', None)
        super().__init__(*args, **kwargs)
        if assessment:
            self.assessment = assessment
            for question in assessment['questions']:
                print(question)
                field_name = f'question_{question["id"]}'
                self.fields[field_name] = forms.ChoiceField(
                    choices=[(choice['id'], choice['text']) for choice in question['choices']],
                    widget=forms.RadioSelect,
                    required=False,  # Make individual question fields not required
                    label=question['text']
                )
                print(self.fields[field_name])

    def clean(self):
        cleaned_data = super().clean()
        answers = {}
        for field_name, value in cleaned_data.items():
            if field_name.startswith('question_'):
                question_id = int(field_name.split('_')[1])
                answers[question_id] = value
        self.cleaned_data['answers'] = answers
        return self.cleaned_data
