from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Assessment, AssessmentResult
from .forms import AssessmentForm
from ml.models import generate_assessment
from studyplans.views import generate_study_plan

@login_required
def initial_assessment(request, topic):
    assessment_data = generate_assessment(topic)
    
    if not assessment_data:
        return render(request, 'assessments/no_assessment.html')

    assessment_instance = Assessment.objects.create(**assessment_data)

    if request.method == 'POST':
        form = AssessmentForm(request.POST)
        if form.is_valid():
            result = form.save(commit=False)
            result.user = request.user
            result.assessment = assessment_instance
            result.save()

            # Generate a study plan based on the assessment results
            study_plan = generate_study_plan(result)

            # Redirect to the study plan page
            return redirect('study_plan')
        else:
            # Handle form validation errors
            print(form.errors)
    else:
        form = AssessmentForm()
    
    return render(request, 'assessments/initial_assessment.html', {'form': form, 'assessment': assessment_instance, 'topic': topic})
